public class Lesson7 {

    public static void main(String[] args){
        Студент Студент1 = new СтудентЗаочник(23);
        System.out.println(Студент1.toString());
    }
}
