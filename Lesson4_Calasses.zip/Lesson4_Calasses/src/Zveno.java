public class Zveno {
    //Zveno ZvenoBefore = new Zveno();
    //Zveno ZvenoAfter = new Zveno();

    int IndexZvenoBefore = 0;
    int IndexZvenoAfter  = 0;

    int Znach = 0;

    public <T extends Number> Zveno(int i, int i1, int a1) {
        this.IndexZvenoBefore = i;
        this.IndexZvenoAfter  = i1;
        //Object a1;
        this.Znach            = (int) a1;
    }





}
