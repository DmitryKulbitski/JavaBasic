public interface algebra {

    public double Norm();

}
