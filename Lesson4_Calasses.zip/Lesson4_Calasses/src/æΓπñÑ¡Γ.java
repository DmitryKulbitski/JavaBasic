public class Студент implements Сотрудник{
    private int StudTicket;

    public Студент(int studTicket) {
        StudTicket = studTicket;
    }

    public Студент() {
    }
}
