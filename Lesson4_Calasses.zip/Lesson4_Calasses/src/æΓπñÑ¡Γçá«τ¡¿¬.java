public class СтудентЗаочник extends Студент {
    private int StudTicket;

    public СтудентЗаочник(int studTicket) {
        StudTicket = studTicket;
    }

    @Override
    public String toString() {
        return "СтудентЗаочник{" +
                "StudTicket=" + StudTicket +
                '}';
    }
}
