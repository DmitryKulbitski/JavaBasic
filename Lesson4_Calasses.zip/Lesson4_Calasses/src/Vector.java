public class Vector implements algebra {

    int [] arr = new int[10];

    public Vector(int a1, int a2, int a3, int a4, int a5, int a6, int a7, int a8, int a9, int a10){


        this.arr[0] = a1;
        this.arr[1] = a2;
        this.arr[2] = a3;
        this.arr[3] = a4;
        this.arr[4] = a5;
        this.arr[5] = a6;
        this.arr[6] = a7;
        this.arr[7] = a8;
        this.arr[8] = a9;
        this.arr[9] = a10;

    }

    @Override
    public double Norm() {

        int summ = 0;

        for(int i = 0; i < 10; i++){
            summ = summ + Math.abs(this.arr[i]);

        }

        return (int) Math.sqrt(summ);
    }
}
