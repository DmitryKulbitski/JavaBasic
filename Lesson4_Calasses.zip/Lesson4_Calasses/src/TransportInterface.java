
public interface TransportInterface {


    //public void Transport();

    //public String Name = "";
    //public String Place = "";


    //public String getName(Transport T);
    //public String getName();

    public void move();


}