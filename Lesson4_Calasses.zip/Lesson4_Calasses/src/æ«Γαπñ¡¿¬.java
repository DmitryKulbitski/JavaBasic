public interface Сотрудник {
}
