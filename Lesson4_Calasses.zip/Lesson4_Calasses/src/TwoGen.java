
public class TwoGen<T extends Number, V extends Number> {
    private T ob1;
    private V ob2;
    // Конструктору класса передаются ссылки
    // на объекты типов T и V
    public TwoGen(T o1, V o2) {
        ob1 = o1;
        ob2 = o2;
    }
    // Отображение типов T и V
    public void showTypes() {
        System.out.println("Type of T is "+ ob1.getClass().getName());
        System.out.println("Type of V is "+ ob2.getClass().getName());
    }
    public T getob1() {
        return ob1;
    }
    public V getob2() {
        return ob2;
    }
    
    public double Summ(){
        double t = (this.ob1.doubleValue() + this.ob2.doubleValue());
        return t;
                
    }
}