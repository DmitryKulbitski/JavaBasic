public interface Geometr {
}
