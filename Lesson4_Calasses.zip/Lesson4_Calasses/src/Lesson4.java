public class Lesson4 {

    public static void main(String[] args) {
        Book Book1 = new Book();

        //Book1.SetAvtor();
        //System.out.println(Book1.avtor);
        System.out.println(Book1.ToString());
    }

}
